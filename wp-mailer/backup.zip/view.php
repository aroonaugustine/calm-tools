<?php
/**
 * CALM Mailer — View in Browser v2.5.0
 * Renders the exact email body for a user in English (en) or Simplified Chinese (zh).
 * URL examples:
 *   /wp-mailer/view.php?login=aa&campaign=20250924&lang=en
 *   /wp-mailer/view.php?_se=base64url(email@x.com)&lang=zh
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
if (!defined('WP_DISABLE_FATAL_ERROR_HANDLER')) define('WP_DISABLE_FATAL_ERROR_HANDLER', true);

require('/var/www/html/wp-load.php'); // adjust if needed

// --- Params ---
$login    = trim((string)($_GET['login'] ?? ''));
$uidParam = isset($_GET['user']) ? (int)$_GET['user'] : 0;
$se       = trim((string)($_GET['_se'] ?? '')); // base64url email
$lang     = strtolower(trim((string)($_GET['lang'] ?? 'en')));
if (!in_array($lang, ['en','zh'], true)) $lang='en';

// -- Resolve user --
$user = null;
if ($login!=='') $user = get_user_by('login',$login);
if (!$user && $uidParam>0) $user = get_user_by('id',$uidParam);
if (!$user && $se!=='') {
  $b64 = strtr($se,'-_','+/'); $pad = strlen($b64)%4; if ($pad) $b64 .= str_repeat('=', 4-$pad);
  $email = filter_var(base64_decode($b64), FILTER_VALIDATE_EMAIL) ?: '';
  if ($email) $user = get_user_by('email',$email);
}
if (!$user) {
  http_response_code(404);
  header('Content-Type: text/html; charset=utf-8');
  echo "<h3>Not found</h3><p>User not found.</p>";
  exit;
}

// --- Helpers copied from sender (subset) ---
function ld_user_course_ids($user_id){
  $ids=[];
  if (function_exists('learndash_user_get_enrolled_courses')) $ids=(array)learndash_user_get_enrolled_courses($user_id);
  elseif (function_exists('ld_get_mycourses')) $ids=(array)ld_get_mycourses($user_id);
  if (function_exists('learndash_get_users_group_ids') && function_exists('learndash_group_enrolled_courses')){
    $gids=(array)learndash_get_users_group_ids($user_id);
    foreach($gids as $gid){ $g=(array)learndash_group_enrolled_courses($gid); $ids=array_merge($ids,$g); }
  }
  $ids=array_values(array_unique(array_map('intval',$ids))); sort($ids,SORT_NUMERIC); return $ids;
}
function ld_course_is_completed($user_id,$course_id){
  if (function_exists('learndash_course_completed') && learndash_course_completed($user_id,$course_id)) return true;
  $meta = get_user_meta($user_id,'course_completed_'.$course_id,true);
  if (!empty($meta)) return true;
  if (function_exists('learndash_course_status')) {
    $st = learndash_course_status($course_id,$user_id);
    if (is_string($st) && stripos($st,'Completed')!==false) return true;
  }
  return false;
}
function ld_course_percent($user_id,$course_id){
  if (ld_course_is_completed($user_id,$course_id)) return 100;
  if (function_exists('learndash_course_progress')){
    $p=learndash_course_progress(['user_id'=>$user_id,'course_id'=>$course_id,'array'=>true]);
    if (is_array($p) && isset($p['percentage'])) {
      $perc = is_numeric($p['percentage'])?(float)$p['percentage']:(float)str_replace('%','',(string)$p['percentage']);
      return (int)max(0,min(100,round($perc)));
    }
    if (is_array($p) && isset($p['completed'],$p['total']) && (int)$p['total']>0){
      $perc = ((int)$p['completed']/(int)$p['total'])*100.0;
      return (int)max(0,min(100,round($perc)));
    }
  }
  return 0;
}
function course_titles(array $cids): array {
  $out=[]; foreach ($cids as $cid){ $t=get_the_title($cid) ?: "Course {$cid}"; $out[$cid]=preg_replace('/\s+/',' ',trim($t)); }
  return $out;
}
function calm_first_name($u){
  $fn=(string)get_user_meta($u->ID,'first_name',true); if ($fn==='') $fn=$u->display_name?:$u->user_login; return $fn;
}
function generic_reset_page(){ return 'https://portcalm.portcitybpo.lk/en/password-reset/'; }

// --- Build body same as email ---
$consider = ld_user_course_ids($user->ID); // show all user courses in viewer
$titles   = course_titles($consider);
$any_incomplete = false;
$list='';
foreach ($consider as $cid){
  $pct = ld_course_percent($user->ID,$cid);
  if ($pct < 100) $any_incomplete = true;
  $list .= '<li>'.esc_html($titles[$cid]).' – '.intval($pct).'%</li>';
}
$course_list_html = '<ul style="padding-left:20px; margin-top:8px;">'.$list.'</ul>';

$first = esc_html(calm_first_name($user));
$email = esc_html($user->user_email);
$reset = esc_url(generic_reset_page());

// EN/中文 text blocks
$logo = 'https://portcalm.portcitybpo.lk/wp-content/uploads/2025/03/Port-City-BPO-logo-hd-1.webp';

if ($lang==='en'){
  $title = 'CALM – Your Course Progress';
  $intro_incomplete = <<<HTML
  <p>We’d like to share your current progress on the <strong>CALM Platform</strong> (Compliance And Learning Management). Completing these courses is <strong>mandatory</strong> to stay aligned with company standards.</p>
  <div style="margin: 18px 0; padding: 16px; background:#f0f8ff; border-left:4px solid #0077b6;">
    <p style="margin:0 0 8px 0;"><strong>Login email:</strong> {$email}</p>
    <p style="margin:0;">If you need to reset your password, please use this link:<br>
      <a href="{$reset}" target="_blank" rel="noopener">{$reset}</a>
    </p>
  </div>
HTML;
  $congrats = "<p>Fantastic news — you’ve completed all your assigned compliance courses on the <strong>CALM Platform</strong>!</p>";
  $list_hdr = '<h3 style="color:#004b6b; margin-top:18px;">Your Course Progress</h3>';
  $footer = <<<HTML
  <p style="margin-top:16px;">Please log in and complete any outstanding modules at your earliest convenience. The platform includes training modules, policy documents, and progress tracking to support your development.</p>
  <h3 style="color:#004b6b; margin-top:18px;">Helpful Links</h3>
  <ul>
    <li>Quick Start Guide: <a href="https://portcalm.portcitybpo.lk/get-started/" target="_blank" rel="noopener">Get Started</a></li>
    <li>Change Password: <a href="https://portcalm.portcitybpo.lk/account/password/" target="_blank" rel="noopener">Change Password</a></li>
    <li>Forgot Password: <a href="https://portcalm.portcitybpo.lk/en/password-reset/" target="_blank" rel="noopener">Password Reset</a></li>
  </ul>
  <p>If you require any assistance:</p>
  <ul style="list-style:none; padding-left:0;">
    <li><strong>Contact Support:</strong> <a href="mailto:calm@portcitybpo.lk">calm@portcitybpo.lk</a></li>
    <li><strong>Help Center:</strong> <a href="https://portcalm.portcitybpo.lk/faqs/" target="_blank" rel="noopener">CALM FAQs</a></li>
  </ul>
  <p style="margin-top:18px;">Warm regards,</p>
  <strong>The CALM Team</strong>
HTML;
} else {
  $title = 'CALM – 课程进度';
  $intro_incomplete = <<<HTML
  <p>以下是您在 <strong>CALM 平台</strong>（合规与学习管理平台）的课程进度。为确保符合公司标准，请尽快完成所有必修课程。</p>
  <div style="margin: 18px 0; padding: 16px; background:#f0f8ff; border-left:4px solid #0077b6;">
    <p style="margin:0 0 8px 0;"><strong>登录邮箱：</strong> {$email}</p>
    <p style="margin:0;">如需重置密码，请使用以下链接：<br>
      <a href="{$reset}" target="_blank" rel="noopener">{$reset}</a>
    </p>
  </div>
HTML;
  $congrats = "<p>太棒了！您已完成 <strong>CALM 平台</strong> 的所有指定合规课程，感谢您的配合。</p>";
  $list_hdr = '<h3 style="color:#004b6b; margin-top:18px;">课程进度</h3>';
  $footer = <<<HTML
  <p style="margin-top:16px;">请尽快登录平台完成未完成的模块。平台包含培训课程、政策文档及进度跟踪功能，助您顺利完成学习。</p>
  <h3 style="color:#004b6b; margin-top:18px;">常用链接</h3>
  <ul>
    <li>快速入门：<a href="https://portcalm.portcitybpo.lk/get-started/" target="_blank" rel="noopener">Get Started</a></li>
    <li>修改密码：<a href="https://portcalm.portcitybpo.lk/account/password/" target="_blank" rel="noopener">Change Password</a></li>
    <li>忘记密码：<a href="https://portcalm.portcitybpo.lk/en/password-reset/" target="_blank" rel="noopener">Password Reset</a></li>
  </ul>
  <p>如需帮助：</p>
  <ul style="list-style:none; padding-left:0;">
    <li><strong>技术支持：</strong> <a href="mailto:calm@portcitybpo.lk">calm@portcitybpo.lk</a></li>
    <li><strong>帮助中心：</strong> <a href="https://portcalm.portcitybpo.lk/faqs/" target="_blank" rel="noopener">CALM FAQs</a></li>
  </ul>
  <p style="margin-top:18px;">此致</p>
  <strong>CALM 团队</strong>
HTML;
}

$greet = "<p>Dear <strong>{$first}</strong>,</p>";
if ($lang==='zh') $greet = "<p>您好，<strong>{$first}</strong>：</p>";

$body_core = $any_incomplete
  ? ($greet.$intro_incomplete.$list_hdr.$course_list_html)
  : ($greet.$congrats.$list_hdr.$course_list_html);

$html = <<<HTML
<!doctype html><meta charset="utf-8">
<div style="font-family:Helvetica,Arial,sans-serif;color:#333;line-height:1.6;max-width:800px;margin:auto;padding:30px 20px;border:1px solid #ddd;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,.05);background:#fff;">
  <div style="text-align:center;margin-bottom:24px;">
    <img style="max-width:100px;width:100%;height:auto;display:block;margin:0 auto;border-radius:12px;" src="{$logo}" alt="Port City BPO" />
  </div>
  <h2 style="text-align:center;color:#004b6b;margin-bottom:12px;">{$title}</h2>
  {$body_core}
  {$footer}
</div>
HTML;

header('Content-Type: text/html; charset=utf-8');
echo $html;
